package main;

import dao.OrderProcessor;
import entity.*;
import java.util.*;

public class MainModule {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        OrderProcessor processor = new OrderProcessor();

        while (true) {
            System.out.println("\n1. Create User\n2. Create Product\n3. Cancel Order\n4. Get All Products\n5. Get Orders By User\n6. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter user ID: ");
                    int uid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter username: ");
                    String uname = sc.nextLine();
                    System.out.print("Enter password: ");
                    String pwd = sc.nextLine();
                    System.out.print("Enter role: ");
                    String role = sc.nextLine();
                    processor.createUser(new User(uid, uname, pwd, role));
                    break;
                case 2:
                    System.out.print("Enter product ID: ");
                    int pid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter name: ");
                    String pname = sc.nextLine();
                    System.out.print("Enter description: ");
                    String desc = sc.nextLine();
                    System.out.print("Enter price: ");
                    double price = sc.nextDouble();
                    System.out.print("Enter quantity: ");
                    int qty = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter type (Electronics/Clothing): ");
                    String type = sc.nextLine();

                    Product product = new Product(pid, pname, desc, price, qty, type);
                    processor.createProduct(product);
                    break;
                case 3:
                    System.out.print("Enter order ID to cancel: ");
                    int oid = sc.nextInt();
                    processor.cancelOrder(oid);
                    break;
                case 4:
                    List<Product> products = processor.getAllProducts();
                    for (Product p : products) {
                        System.out.println(p.getProductId() + ", " + p.getProductName() + ", " + p.getPrice());
                    }
                    break;
                case 5:
                    System.out.print("Enter user ID: ");
                    int uid2 = sc.nextInt();
                    List<String> orders = processor.getOrdersByUser(uid2);
                    for (String order : orders) {
                        System.out.println(order);
                    }
                    break;
                case 6:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
