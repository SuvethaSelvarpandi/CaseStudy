/**
 * 
 */
/**
 * 
 */
module CodingChallenge {
	requires java.sql;
}