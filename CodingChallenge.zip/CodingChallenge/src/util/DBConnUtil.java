//package util;
//
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.util.Properties;
//
//public class DBConnUtil {
//    private static Connection connection;
//
//    public static Connection getDBConn() {
//        if (connection != null) return connection;
//        Properties props = new Properties();
//        try (FileInputStream fis = new FileInputStream("db.properties")) {
//            props.load(fis);
//            String driver = props.getProperty("db.driver");
//            String url = props.getProperty("db.url");
//            String username = props.getProperty("db.username");
//            String password = props.getProperty("db.password");
//
//            Class.forName(driver);
//            connection = DriverManager.getConnection(url, username, password);
//        } catch (IOException | SQLException | ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//        return connection;
//    }
//}
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.io.FileInputStream;

public class DBConnUtil {

    public static Connection getDBConn() {
        Connection conn = null;
        try {
            // Load database properties
            Properties props = new Properties();
            FileInputStream fis = new FileInputStream("db.properties"); // Make sure the file is in project root
            props.load(fis);

            // Read properties
            String driver = props.getProperty("db.driver");
            String url = props.getProperty("db.url");
            String username = props.getProperty("db.username");
            String password = props.getProperty("db.password");

            // Load JDBC driver
            Class.forName(driver);

            // Establish connection
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Database connected successfully.");

        } catch (Exception e) {
            System.out.println(" DB connection error: " + e.getMessage());
        }

        return conn;
    }
}
