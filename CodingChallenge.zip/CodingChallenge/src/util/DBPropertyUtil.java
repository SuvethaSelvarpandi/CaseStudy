package util;

import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static Properties getPropertyString(String filename) {
        Properties props = new Properties();
        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream(filename)) {
            props.load(input);
        } catch (Exception e) {
            System.out.println("Error reading property file: " + e.getMessage());
        }
        return props;
    }
}
