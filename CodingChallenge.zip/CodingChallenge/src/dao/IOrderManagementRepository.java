package dao;

import entity.*;
import java.util.List;

public interface IOrderManagementRepository {
    void createUser(User user);
    void createProduct(Product product);
    void cancelOrder(int orderId);
    List<Product> getAllProducts();
    List<String> getOrdersByUser(int userId);
}