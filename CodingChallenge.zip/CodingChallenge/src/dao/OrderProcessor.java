package dao;

import entity.*;
import util.DBConnUtil;
import java.sql.*;
import java.util.*;

public class OrderProcessor implements IOrderManagementRepository {

    @Override
    public void createUser(User user) {
        try (Connection conn = DBConnUtil.getDBConn()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (user_id, username, password, role) VALUES (?, ?, ?, ?)");
            ps.setInt(1, user.getUserId());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
            System.out.println("User created successfully.");
        } catch (SQLException e) {
            System.out.println("Error creating user: " + e.getMessage());
        }
    }

    @Override
    public void createProduct(Product product) {
        try (Connection conn = DBConnUtil.getDBConn()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO products (product_id, name, description, price, quantity, type) VALUES (?, ?, ?, ?, ?, ?)");
            ps.setInt(1, product.getProductId());
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getDescription());
            ps.setDouble(4, product.getPrice());
            ps.setInt(5, product.getQuantityInStock());
            ps.setString(6, product.getType());
            ps.executeUpdate();
            System.out.println("Product created successfully.");
        } catch (SQLException e) {
            System.out.println("Error creating product: " + e.getMessage());
        }
    }

    @Override
    public void cancelOrder(int orderId) {
        try (Connection conn = DBConnUtil.getDBConn()) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM orders WHERE order_id = ?");
            ps.setInt(1, orderId);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                System.out.println("Order cancelled successfully.");
            } else {
                System.out.println("Order not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error cancelling order: " + e.getMessage());
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        try (Connection conn = DBConnUtil.getDBConn(); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery("SELECT * FROM products");
            while (rs.next()) {
                Product p = new Product(
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("quantity"),
                    rs.getString("type")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching products: " + e.getMessage());
        }
        return list;
    }

    @Override
    public List<String> getOrdersByUser(int userId) {
        List<String> list = new ArrayList<>();
        try (Connection conn = DBConnUtil.getDBConn()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM orders WHERE user_id = ?");
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add("Order ID: " + rs.getInt("order_id") + ", Product ID: " + rs.getInt("product_id") + ", Quantity: " + rs.getInt("quantity"));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching orders: " + e.getMessage());
        }
        return list;
    }
}