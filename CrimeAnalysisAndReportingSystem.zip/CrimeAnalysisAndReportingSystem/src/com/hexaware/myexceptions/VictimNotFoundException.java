package com.hexaware.myexceptions;

public class VictimNotFoundException extends Exception {
    public VictimNotFoundException(String message) {
        super(message);
    }
}