package com.hexaware.myexceptions;

public class SuspectNotFoundException extends Exception {
    public SuspectNotFoundException(String message) {
        super(message);
    }
}