package com.hexaware.myexceptions;

public class OfficerNotFoundException extends Exception {
    public OfficerNotFoundException(String message) {
        super(message);
    }
}