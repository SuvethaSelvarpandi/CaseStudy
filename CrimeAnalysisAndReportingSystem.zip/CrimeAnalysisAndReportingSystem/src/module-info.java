/**
 * 
 */
/**
 * 
 */
module CrimeAnalysisAndReportingSystem {
    requires java.sql;
    requires org.junit.jupiter.api; // only if you're using JUnit 5
    exports entity;
    exports dao;
    exports com.hexaware.myexceptions;
}
